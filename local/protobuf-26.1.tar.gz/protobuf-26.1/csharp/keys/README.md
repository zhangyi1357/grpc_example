Contents
--------

- Google.Protobuf.public.snk:
  Public key to verify strong name of Google.Protobuf assemblies.
- Google.Protobuf.snk:
  Signing key to provide strong name of Google.Protobuf assemblies.
  As per [Microsoft guidance](https://msdn.microsoft.com/en-us/library/wd40t7ad(v=vs.110).aspx)
  signing key should be checked into the repository.
