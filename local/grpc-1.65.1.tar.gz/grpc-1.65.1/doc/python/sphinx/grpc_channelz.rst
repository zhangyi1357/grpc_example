gRPC Channelz
====================

What is gRPC Channelz?
---------------------------------------------

Design Document `gRPC Channelz <https://github.com/grpc/proposal/blob/master/A14-channelz.md>`_

Module Contents
---------------

.. automodule:: grpc_channelz.v1.channelz
